package ch.bbbaden.lb_151;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author delia
 */
public class WordRepository {         


    public String[] getWords() throws SQLException {
        
        String url = "jdbc:mysql://localhost/wordlist";
        String username = "root";
        String password = "";
        
        List<String> words = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT word FROM words";
            PreparedStatement statement = connection.prepareStatement(query);

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String word = resultSet.getString("word");
                words.add(word);
            }
        }

        return words.toArray(new String[0]);
    }
}

