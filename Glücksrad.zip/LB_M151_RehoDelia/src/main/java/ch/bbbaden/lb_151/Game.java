/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.lb_151;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.inject.Named;

/**
 *
 * @author delia
 */
@Named(value = "gameBean")
public class Game {
    
    private static final int lifepoints = 3;
    private static final String[] words = {"hangman", "computer", "sleep"};
    
    private String hiddenWord;
    private String guessedWord;
    private int misses;
    private List<Character> guessedLetters;
    
    public Game(){
        Random random = new Random();
        hiddenWord = words[random.nextInt(words.length)];
        guessedWord = "";
        for (int i = 0; i < hiddenWord.length(); i++){
            guessedWord += "_";
        }
        misses = 0;
        guessedLetters = new ArrayList<Character>();
        
    }

    public String getHiddenWord() {
        return hiddenWord;
    }

    public String getGuessedWord() {
        return guessedWord;
    }

    public int getMisses() {
        return misses;
    }

    public List<Character> getGuessedLetters() {
        return guessedLetters;
    }
    
    public boolean guessLetter(char letter){
        boolean correct = false;
        for (int i = 0; i < hiddenWord.length(); i++){
            if (hiddenWord.charAt(i) == letter) {
                guessedWord = guessedWord.substring(0,i) + letter +  guessedWord.substring(i+1);
                correct = true;
            }
        }
        
        if(!correct){
            misses++;
        }
        
        guessedLetters.add(letter);
        return correct;
    }
    
    public boolean isGameOver(){
        if(misses >= lifepoints){
            return true;
        }
        
        if(guessedWord.equals(hiddenWord)){
            return true;
        }
        
        return false;
    }
}
