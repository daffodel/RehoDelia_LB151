/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.lb_151;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author delia
 */
@ManagedBean
@Named(value = "gameBean")
@RequestScoped
public class GameBean {
    
    private Game game;
    private char guess;

    public GameBean() {
        game = new Game();
    }

    public String getHiddenWord() {
        return game.getHiddenWord();
    }

    public String getGuessedWord() {
        return game.getGuessedWord();
    }

    public int getMisses() {
        return game.getMisses();
    }

    public List<Character> getGuessedLetters() {
        return game.getGuessedLetters();
    }

    public char getGuess() {
        return guess;
    }

    public void setGuess(char guess) {
        this.guess = guess;
    }

    public void makeGuess() {
        game.guessLetter(guess);
    }
}
