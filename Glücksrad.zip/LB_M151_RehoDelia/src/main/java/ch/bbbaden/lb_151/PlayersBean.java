/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.lb_151;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author delia
 */
@ManagedBean
@Named(value = "playersBean")
@RequestScoped
public class PlayersBean {

    /**
     * Creates a new instance of PlayersBean
     */
    public PlayersBean() {
    }
    
    private String playername;

    public String getPlayername() {
        return playername;
    }

    public void setPlayername(String playername) {
        this.playername = playername;
    }
    
    public void addPlayers(String playername){
          try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gluecksrad", "root", "password");
            PreparedStatement stmt = con.prepareStatement("INSERT INTO players (name) VALUES (?)");
            stmt.setString(1, playername);
            stmt.executeUpdate();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private Connection getConnection() throws ClassNotFoundException {
    
        Connection connect = null;
        String url = "jdbc:mysql://localhost:3306/gluecksrad";
        String username = "root";
        String password = "";
        try {
          Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection(url, username, password);
         } catch (SQLException ex) {
          Logger.getLogger(PlayersBean.class.getName()).log(Level.SEVERE, null, ex);
         }
        return connect;
    }
    
        //connect to DB and get players list
    public List<Players> getPlayersList() throws SQLException, ClassNotFoundException {

        //get database connection
        Connection con = this.getConnection();

        if (con == null) {
            throw new SQLException("Can't get database connection");
        }

        PreparedStatement ps
                = con.prepareStatement(
                        "select playername, time, money, rounds, highscore from players");

        //get player data from database
        ResultSet result = ps.executeQuery();

        List<Players> list = new ArrayList<>();

        while (result.next()) {
            Players play = new Players();

            play.setPlayername(result.getString("playername"));
            play.setTime(result.getDate("time"));
            play.setMoney(result.getInt("money"));
            play.setRounds(result.getInt("rounds"));
            play.setHighscore(result.getInt("highscore"));

            //store all data into a List
            list.add(play);
        }

        return list;
    }
}

